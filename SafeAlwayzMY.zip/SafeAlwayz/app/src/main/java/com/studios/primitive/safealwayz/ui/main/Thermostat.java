package com.studios.primitive.safealwayz.ui.main;

import java.io.Serializable;

public class Thermostat implements Serializable {
    private String thermostatName;
    private int id;
    private int accountId;
    private double indoorTemp;
    private double outdoorTemp;
    private boolean power;
    private String acMode;

    //Thermostat constructor
    public Thermostat(int accountId, String thermostatName){
        this.thermostatName = thermostatName;
        this.accountId = accountId;
        this.id = id;
        this.indoorTemp = indoorTemp;
        this.outdoorTemp = outdoorTemp;
        this.power = false;
        this.acMode = acMode;
    }

    public Thermostat(){

    }

    //toString
    @Override
    public String toString(){
        return "Thermastat name: " + thermostatName + "\n" +
                "Thermastat ID " + id + "\n" +
                "Account ID: " + accountId + "\n";

    }



    //Getters & setters

    public int getAccountId(){ return accountId; }
    public void setAccountId(int accountId){ this.accountId = accountId; }



    public String getThermostatName(){ return thermostatName; }
    public void setThermostatName(){ this.thermostatName = thermostatName; }

    public int getId(){ return id; }
    public void setId(int thermostatID) { this.id = id; }

    public double getIndoorTemp(){ return indoorTemp; }
    public void setIndoorTemp(){ this.indoorTemp = indoorTemp; }

    public double getOutdoorTemp(){ return outdoorTemp; }
    public void setOutdoorTemp(){ this.outdoorTemp = outdoorTemp; }

    public boolean isPower() { return this.power; }
    public void setPower(boolean power) { this.power = power; }

}
