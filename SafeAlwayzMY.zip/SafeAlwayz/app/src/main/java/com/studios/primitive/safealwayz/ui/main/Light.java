package com.studios.primitive.safealwayz.ui.main;

public class Light {
}
