package com.studios.primitive.safealwayz.ui.main;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBThermostat extends SQLiteOpenHelper {
    public static final String THERMOSTATS = "THERMOSTATS";
    public static final String COLUMN_ID = "ID";
    public static final String ACCOUNT_ID = "ACCOUNT_ID";
    public static final String COLUMN_NAME = "NAME";

    public DBThermostat(@Nullable Context context) { super(context, "thermostat.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        String createTableStatement = "CREATE TABLE " + THERMOSTATS + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + ACCOUNT_ID + " INTEGER, " + COLUMN_NAME + " TEXT UNIQUE)";
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1){
        //
    }

    public boolean addThermostat(Thermostat thermostat){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(ACCOUNT_ID, thermostat.getAccountId());
        cv.put(COLUMN_NAME, thermostat.getThermostatName());
        long insert = db.insert(THERMOSTATS, null, cv);
        return insert != -1;
    }

    public List<Thermostat> getAllThermostats(){
        List<Thermostat> returnList = new ArrayList<>();
        String queryCommand = "SELECT * FROM " + THERMOSTATS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryCommand, null);
        if(cursor.moveToFirst()){
            do{
                int thermostatID = cursor.getInt(0);
                int accountID = cursor.getInt(1);
                String thermostatName = cursor.getString(2);

                Thermostat newThermostat = new Thermostat(accountID, thermostatName);
                newThermostat.setId(thermostatID);
                returnList.add(newThermostat);
            }while(cursor.moveToNext());
        }else{
            //return empty list
        }
        cursor.close();
        db.close();
        return returnList;
    }

    public Thermostat getThermostat(String name){
        Thermostat thermostat = new Thermostat();
        SQLiteDatabase db = this.getReadableDatabase();
        String queryCommand = "SELECT * FROM " + THERMOSTATS + " WHERE " + COLUMN_NAME + " = " + "'" + name + "'";
        Cursor cursor = db.rawQuery(queryCommand, null);
        if(cursor.moveToFirst()){
            do{
                int thermostatID = cursor.getInt(0);
                int accountID = cursor.getInt(1);
                String thermostatName = cursor.getString(2);

                thermostat.setId(thermostatID);
                thermostat.setAccountId(accountID);
                thermostat.setThermostatName();
            }while(cursor.moveToNext());
        }else{
            //return empty list
        }
        cursor.close();
        db.close();
        return thermostat;
    }

    public boolean deleteThermostat(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        String queryCommand = "DELETE FROM "+ THERMOSTATS + " WHERE " + COLUMN_NAME + "=" + name;
        Cursor cursor = db.rawQuery(queryCommand, null);
        if(cursor.moveToFirst()){
            return true;
        }else{
            return false;
        }

    }

}
