package com.studios.primitive.safealwayz;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.studios.primitive.safealwayz.ui.main.Account.AccountModel;
import com.studios.primitive.safealwayz.ui.main.DBThermostat;
import com.studios.primitive.safealwayz.ui.main.Thermostat;

public class AddThermostatActivity extends AppCompatActivity {

    String name;
    int accountId;
    EditText nameInput;

    Button addThermostatBtn;
    Button cancelAddThermostatBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_thermostat);

        nameInput = (EditText) findViewById(R.id.thermostat_name);

        addThermostatBtn = (Button) findViewById(R.id.add_thermostat);
        addThermostatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AccountModel model = (AccountModel) getIntent().getSerializableExtra("obj");
                accountId = model.getId();
                name = nameInput.getText().toString();
                Thermostat newThermostat = new Thermostat(accountId, name);
                DBThermostat dbthermo = new DBThermostat(AddThermostatActivity.this);
                dbthermo.addThermostat(newThermostat);
                finish();
            }
        });
    }
}